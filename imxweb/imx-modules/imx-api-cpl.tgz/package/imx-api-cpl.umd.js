(function (global, factory) {
    typeof exports === 'object' && typeof module !== 'undefined' ? factory(exports, require('imx-qbm-dbts')) :
    typeof define === 'function' && define.amd ? define(['exports', 'imx-qbm-dbts'], factory) :
    (global = global || self, factory(global['imx-api'] = {}, global.imxQbmDbts));
}(this, (function (exports, imxQbmDbts) { 'use strict';

    var __extends = (undefined && undefined.__extends) || (function () {
        var extendStatics = function (d, b) {
            extendStatics = Object.setPrototypeOf ||
                ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
                function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
            return extendStatics(d, b);
        };
        return function (d, b) {
            if (typeof b !== "function" && b !== null)
                throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
            extendStatics(d, b);
            function __() { this.constructor = d; }
            d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
        };
    })();
    var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
        function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
        return new (P || (P = Promise))(function (resolve, reject) {
            function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
            function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
            function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
            step((generator = generator.apply(thisArg, _arguments || [])).next());
        });
    };
    var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
        var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
        return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
        function verb(n) { return function (v) { return step([n, v]); }; }
        function step(op) {
            if (f) throw new TypeError("Generator is already executing.");
            while (_) try {
                if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
                if (y = 0, t) op = [op[0] & 2, t.value];
                switch (op[0]) {
                    case 0: case 1: t = op; break;
                    case 4: _.label++; return { value: op[1], done: false };
                    case 5: _.label++; y = op[1]; op = [0]; continue;
                    case 7: op = _.ops.pop(); _.trys.pop(); continue;
                    default:
                        if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                        if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                        if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                        if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                        if (t[2]) _.ops.pop();
                        _.trys.pop(); continue;
                }
                op = body.call(thisArg, _);
            } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
            if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
        }
    };
    var TypedClient = /** @class */ (function () {
        function TypedClient(client, translationProvider) {
            this.PortalCandidatesMitigatingcontrol = new PortalCandidatesMitigatingcontrolWrapper(client, translationProvider);
            this.PortalPersonMitigatingcontrols = new PortalPersonMitigatingcontrolsWrapper(client, translationProvider);
            this.PortalPersonMitigatingcontrolsInteractive = new PortalPersonMitigatingcontrolsInteractiveWrapper(client, translationProvider);
            this.PortalPersonRolemembershipsNoncompliance = new PortalPersonRolemembershipsNoncomplianceWrapper(client, translationProvider);
            this.PortalRules = new PortalRulesWrapper(client, translationProvider);
            this.PortalRulesMitigatingcontrols = new PortalRulesMitigatingcontrolsWrapper(client, translationProvider);
            this.PortalRulesViolations = new PortalRulesViolationsWrapper(client, translationProvider);
            this.PortalRulesWorkingcopiesMitigatingcontrols = new PortalRulesWorkingcopiesMitigatingcontrolsWrapper(client, translationProvider);
        }
        return TypedClient;
    }());
    var PortalCandidatesMitigatingcontrol = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrol, _super);
        function PortalCandidatesMitigatingcontrol() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalCandidatesMitigatingcontrol.GetEntitySchema = function () {
            var columns = {
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'MitigatingControl', Columns: columns };
        };
        return PortalCandidatesMitigatingcontrol;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalCandidatesMitigatingcontrol type. */
    var PortalCandidatesMitigatingcontrolInteractive = /** @class */ (function (_super) {
        __extends(PortalCandidatesMitigatingcontrolInteractive, _super);
        function PortalCandidatesMitigatingcontrolInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalCandidatesMitigatingcontrolInteractive;
    }(PortalCandidatesMitigatingcontrol));
    var PortalPersonMitigatingcontrols = /** @class */ (function (_super) {
        __extends(PortalPersonMitigatingcontrols, _super);
        function PortalPersonMitigatingcontrols() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.UID_PersonWantsOrg = _this.GetEntityValue('UID_PersonWantsOrg');
            _this.UID_PersonInNCHasMControl = _this.GetEntityValue('UID_PersonInNCHasMControl');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.UID_NonCompliance = _this.GetEntityValue('UID_NonCompliance');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPersonMitigatingcontrols.GetEntitySchema = function () {
            var columns = {
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'UID_PersonWantsOrg': {
                    ColumnName: 'UID_PersonWantsOrg',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
                'UID_PersonInNCHasMControl': {
                    ColumnName: 'UID_PersonInNCHasMControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_NonCompliance': {
                    ColumnName: 'UID_NonCompliance',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PersonInNCHasMControl', Columns: columns };
        };
        return PortalPersonMitigatingcontrols;
    }(imxQbmDbts.ReadExtTypedEntity));
    /** @deprecated Use the PortalPersonMitigatingcontrols type. */
    var PortalPersonMitigatingcontrolsInteractive = /** @class */ (function (_super) {
        __extends(PortalPersonMitigatingcontrolsInteractive, _super);
        function PortalPersonMitigatingcontrolsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPersonMitigatingcontrolsInteractive;
    }(PortalPersonMitigatingcontrols));
    var PortalPersonRolemembershipsNoncompliance = /** @class */ (function (_super) {
        __extends(PortalPersonRolemembershipsNoncompliance, _super);
        function PortalPersonRolemembershipsNoncompliance() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.XOrigin = _this.GetEntityValue('XOrigin');
            _this.XDateInserted = _this.GetEntityValue('XDateInserted');
            _this.UID_NonCompliance = _this.GetEntityValue('UID_NonCompliance');
            _this.ExceptionValidUntil = _this.GetEntityValue('ExceptionValidUntil');
            _this.IsDecisionMade = _this.GetEntityValue('IsDecisionMade');
            _this.IsExceptionGranted = _this.GetEntityValue('IsExceptionGranted');
            _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
            _this.RiskIndexReduced = _this.GetEntityValue('RiskIndexReduced');
            _this.DecisionDate = _this.GetEntityValue('DecisionDate');
            _this.DecisionReason = _this.GetEntityValue('DecisionReason');
            _this.RoleFullPath = _this.GetEntityValue('RoleFullPath');
            _this.HasMitigation = _this.GetEntityValue('HasMitigation');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalPersonRolemembershipsNoncompliance.GetEntitySchema = function () {
            var columns = {
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XOrigin': {
                    ColumnName: 'XOrigin',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'XDateInserted': {
                    ColumnName: 'XDateInserted',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'UID_NonCompliance': {
                    ColumnName: 'UID_NonCompliance',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ExceptionValidUntil': {
                    ColumnName: 'ExceptionValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'IsDecisionMade': {
                    ColumnName: 'IsDecisionMade',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsExceptionGranted': {
                    ColumnName: 'IsExceptionGranted',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'RiskIndexCalculated': {
                    ColumnName: 'RiskIndexCalculated',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RiskIndexReduced': {
                    ColumnName: 'RiskIndexReduced',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'DecisionDate': {
                    ColumnName: 'DecisionDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'DecisionReason': {
                    ColumnName: 'DecisionReason',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RoleFullPath': {
                    ColumnName: 'RoleFullPath',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasMitigation': {
                    ColumnName: 'HasMitigation',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PersonInNonCompliance', Columns: columns };
        };
        return PortalPersonRolemembershipsNoncompliance;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalPersonRolemembershipsNoncompliance type. */
    var PortalPersonRolemembershipsNoncomplianceInteractive = /** @class */ (function (_super) {
        __extends(PortalPersonRolemembershipsNoncomplianceInteractive, _super);
        function PortalPersonRolemembershipsNoncomplianceInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalPersonRolemembershipsNoncomplianceInteractive;
    }(PortalPersonRolemembershipsNoncompliance));
    var PortalRules = /** @class */ (function (_super) {
        __extends(PortalRules, _super);
        function PortalRules() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.RuleSeverity = _this.GetEntityValue('RuleSeverity');
            _this.isToGrantEver = _this.GetEntityValue('isToGrantEver');
            _this.IsExceptionAllowed = _this.GetEntityValue('IsExceptionAllowed');
            _this.IsInActive = _this.GetEntityValue('IsInActive');
            _this.IsWorkingCopy = _this.GetEntityValue('IsWorkingCopy');
            _this.Ident_ComplianceRule = _this.GetEntityValue('Ident_ComplianceRule');
            _this.Description = _this.GetEntityValue('Description');
            _this.RuleNumber = _this.GetEntityValue('RuleNumber');
            _this.RiskIndex = _this.GetEntityValue('RiskIndex');
            _this.RiskIndexReduced = _this.GetEntityValue('RiskIndexReduced');
            _this.UID_NonCompliance = _this.GetEntityValue('UID_NonCompliance');
            _this.CountOpen = _this.GetEntityValue('CountOpen');
            _this.CountClosed = _this.GetEntityValue('CountClosed');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRules.GetEntitySchema = function () {
            var columns = {
                'RuleSeverity': {
                    ColumnName: 'RuleSeverity',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'isToGrantEver': {
                    ColumnName: 'isToGrantEver',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsExceptionAllowed': {
                    ColumnName: 'IsExceptionAllowed',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsInActive': {
                    ColumnName: 'IsInActive',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'IsWorkingCopy': {
                    ColumnName: 'IsWorkingCopy',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'Ident_ComplianceRule': {
                    ColumnName: 'Ident_ComplianceRule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'Description': {
                    ColumnName: 'Description',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RuleNumber': {
                    ColumnName: 'RuleNumber',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'RiskIndex': {
                    ColumnName: 'RiskIndex',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RiskIndexReduced': {
                    ColumnName: 'RiskIndexReduced',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'UID_NonCompliance': {
                    ColumnName: 'UID_NonCompliance',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'CountOpen': {
                    ColumnName: 'CountOpen',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
                'CountClosed': {
                    ColumnName: 'CountClosed',
                    Type: imxQbmDbts.ValType.Int,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ComplianceRule', Columns: columns };
        };
        return PortalRules;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRules type. */
    var PortalRulesInteractive = /** @class */ (function (_super) {
        __extends(PortalRulesInteractive, _super);
        function PortalRulesInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRulesInteractive;
    }(PortalRules));
    var PortalRulesMitigatingcontrols = /** @class */ (function (_super) {
        __extends(PortalRulesMitigatingcontrols, _super);
        function PortalRulesMitigatingcontrols() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ComplianceRule = _this.GetEntityValue('UID_ComplianceRule');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            _this.UID_NonCompliance = _this.GetEntityValue('UID_NonCompliance');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRulesMitigatingcontrols.GetEntitySchema = function () {
            var columns = {
                'UID_ComplianceRule': {
                    ColumnName: 'UID_ComplianceRule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_NonCompliance': {
                    ColumnName: 'UID_NonCompliance',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ComplianceRuleHasMControl', Columns: columns };
        };
        return PortalRulesMitigatingcontrols;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRulesMitigatingcontrols type. */
    var PortalRulesMitigatingcontrolsInteractive = /** @class */ (function (_super) {
        __extends(PortalRulesMitigatingcontrolsInteractive, _super);
        function PortalRulesMitigatingcontrolsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRulesMitigatingcontrolsInteractive;
    }(PortalRulesMitigatingcontrols));
    var PortalRulesViolations = /** @class */ (function (_super) {
        __extends(PortalRulesViolations, _super);
        function PortalRulesViolations() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.DecisionDate = _this.GetEntityValue('DecisionDate');
            _this.DecisionReason = _this.GetEntityValue('DecisionReason');
            _this.ExceptionValidUntil = _this.GetEntityValue('ExceptionValidUntil');
            _this.RiskIndexCalculated = _this.GetEntityValue('RiskIndexCalculated');
            _this.RiskIndexReduced = _this.GetEntityValue('RiskIndexReduced');
            _this.UID_NonCompliance = _this.GetEntityValue('UID_NonCompliance');
            _this.UID_Person = _this.GetEntityValue('UID_Person');
            _this.UID_PersonDecisionMade = _this.GetEntityValue('UID_PersonDecisionMade');
            _this.UID_QERJustification = _this.GetEntityValue('UID_QERJustification');
            _this.XObjectKey = _this.GetEntityValue('XObjectKey');
            _this.State = _this.GetEntityValue('State');
            _this.HasMitigation = _this.GetEntityValue('HasMitigation');
            _this.CanUserDecide = _this.GetEntityValue('CanUserDecide');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRulesViolations.GetEntitySchema = function () {
            var columns = {
                'DecisionDate': {
                    ColumnName: 'DecisionDate',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'DecisionReason': {
                    ColumnName: 'DecisionReason',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'ExceptionValidUntil': {
                    ColumnName: 'ExceptionValidUntil',
                    Type: imxQbmDbts.ValType.Date,
                    IsReadOnly: true,
                },
                'RiskIndexCalculated': {
                    ColumnName: 'RiskIndexCalculated',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'RiskIndexReduced': {
                    ColumnName: 'RiskIndexReduced',
                    Type: imxQbmDbts.ValType.Double,
                    IsReadOnly: true,
                },
                'UID_NonCompliance': {
                    ColumnName: 'UID_NonCompliance',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_Person': {
                    ColumnName: 'UID_Person',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_PersonDecisionMade': {
                    ColumnName: 'UID_PersonDecisionMade',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_QERJustification': {
                    ColumnName: 'UID_QERJustification',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'XObjectKey': {
                    ColumnName: 'XObjectKey',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'State': {
                    ColumnName: 'State',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'HasMitigation': {
                    ColumnName: 'HasMitigation',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
                'CanUserDecide': {
                    ColumnName: 'CanUserDecide',
                    Type: imxQbmDbts.ValType.Bool,
                    IsReadOnly: true,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'PersonInNonCompliance', Columns: columns };
        };
        return PortalRulesViolations;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRulesViolations type. */
    var PortalRulesViolationsInteractive = /** @class */ (function (_super) {
        __extends(PortalRulesViolationsInteractive, _super);
        function PortalRulesViolationsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRulesViolationsInteractive;
    }(PortalRulesViolations));
    var PortalRulesWorkingcopiesMitigatingcontrols = /** @class */ (function (_super) {
        __extends(PortalRulesWorkingcopiesMitigatingcontrols, _super);
        function PortalRulesWorkingcopiesMitigatingcontrols() {
            var _this = _super !== null && _super.apply(this, arguments) || this;
            _this.UID_ComplianceRule = _this.GetEntityValue('UID_ComplianceRule');
            _this.UID_MitigatingControl = _this.GetEntityValue('UID_MitigatingControl');
            return _this;
        }
        /** Returns the static compile time schema for this type. */
        PortalRulesWorkingcopiesMitigatingcontrols.GetEntitySchema = function () {
            var columns = {
                'UID_ComplianceRule': {
                    ColumnName: 'UID_ComplianceRule',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: true,
                },
                'UID_MitigatingControl': {
                    ColumnName: 'UID_MitigatingControl',
                    Type: imxQbmDbts.ValType.String,
                    IsReadOnly: false,
                },
            };
            columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
            columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
            return { TypeName: 'ComplianceRuleHasMControl', Columns: columns };
        };
        return PortalRulesWorkingcopiesMitigatingcontrols;
    }(imxQbmDbts.TypedEntity));
    /** @deprecated Use the PortalRulesWorkingcopiesMitigatingcontrols type. */
    var PortalRulesWorkingcopiesMitigatingcontrolsInteractive = /** @class */ (function (_super) {
        __extends(PortalRulesWorkingcopiesMitigatingcontrolsInteractive, _super);
        function PortalRulesWorkingcopiesMitigatingcontrolsInteractive() {
            return _super !== null && _super.apply(this, arguments) || this;
        }
        return PortalRulesWorkingcopiesMitigatingcontrolsInteractive;
    }(PortalRulesWorkingcopiesMitigatingcontrols));
    var PortalCandidatesMitigatingcontrolWrapper = /** @class */ (function () {
        function PortalCandidatesMitigatingcontrolWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalCandidatesMitigatingcontrolWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/candidates/MitigatingControl');
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/candidates/MitigatingControl');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalCandidatesMitigatingcontrol, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalCandidatesMitigatingcontrolWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_candidates_MitigatingControl_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalCandidatesMitigatingcontrolWrapper;
    }());
    var PortalPersonMitigatingcontrolsWrapper = /** @class */ (function () {
        function PortalPersonMitigatingcontrolsWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_person_mitigatingcontrols_post(entity.GetColumn('UID_Person').GetValue(), entity.GetColumn('UID_NonCompliance').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_person_mitigatingcontrols_delete(entity.GetColumn('UID_Person').GetValue(), entity.GetColumn('UID_NonCompliance').GetValue(), entity.GetColumn('UID_PersonInNCHasMControl').GetValue());
            };
        }
        PortalPersonMitigatingcontrolsWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalPersonMitigatingcontrolsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}');
        };
        PortalPersonMitigatingcontrolsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPersonMitigatingcontrols, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonMitigatingcontrolsWrapper.prototype.Get = function (UID_Person, UID_NonCompliance, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_get(UID_Person, UID_NonCompliance, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPersonMitigatingcontrolsWrapper.prototype.Post = function (UID_Person, UID_NonCompliance, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_post(UID_Person, UID_NonCompliance, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPersonMitigatingcontrolsWrapper.prototype.Delete = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_delete(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonMitigatingcontrolsWrapper;
    }());
    var PortalPersonMitigatingcontrolsInteractiveWrapper = /** @class */ (function () {
        function PortalPersonMitigatingcontrolsInteractiveWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                return _this.client.portal_person_mitigatingcontrols_interactive_put(entity.GetColumn('UID_Person').GetValue(), entity.GetColumn('UID_NonCompliance').GetValue(), writeData);
            };
            this.deleteMethod = function (entity, deleteData) {
                return _this.client.portal_person_mitigatingcontrols_interactive_delete(entity.GetColumn('UID_Person').GetValue(), entity.GetColumn('UID_NonCompliance').GetValue(), deleteData);
            };
        }
        /** Returns the runtime schema for this method. */
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive');
        };
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive');
                this.builder = new imxQbmDbts.InteractiveTypedEntityBuilder(PortalPersonMitigatingcontrols, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.Put = function (UID_Person, UID_NonCompliance, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_interactive_put(UID_Person, UID_NonCompliance, inputParameterName.InteractiveEntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.Delete = function (UID_Person, UID_NonCompliance, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_interactive_delete(UID_Person, UID_NonCompliance, inputParameterName.InteractiveEntityDeleteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.Get_byid = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_interactive_byid_get(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalPersonMitigatingcontrolsInteractiveWrapper.prototype.Get = function (UID_Person, UID_NonCompliance, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_mitigatingcontrols_interactive_get(UID_Person, UID_NonCompliance, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonMitigatingcontrolsInteractiveWrapper;
    }());
    var PortalPersonRolemembershipsNoncomplianceWrapper = /** @class */ (function () {
        function PortalPersonRolemembershipsNoncomplianceWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalPersonRolemembershipsNoncomplianceWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/person/{UID_Person}/rolememberships/NonCompliance');
        };
        PortalPersonRolemembershipsNoncomplianceWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/person/{UID_Person}/rolememberships/NonCompliance');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalPersonRolemembershipsNoncompliance, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalPersonRolemembershipsNoncomplianceWrapper.prototype.Get = function (UID_Person, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_person_rolememberships_NonCompliance_get(UID_Person, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalPersonRolemembershipsNoncomplianceWrapper;
    }());
    var PortalRulesWrapper = /** @class */ (function () {
        function PortalRulesWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRulesWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/rules');
        };
        PortalRulesWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/rules');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRules, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRulesWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRulesWrapper;
    }());
    var PortalRulesMitigatingcontrolsWrapper = /** @class */ (function () {
        function PortalRulesMitigatingcontrolsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRulesMitigatingcontrolsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/rules/{UID_NonCompliance}/mitigatingcontrols');
        };
        PortalRulesMitigatingcontrolsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/rules/{UID_NonCompliance}/mitigatingcontrols');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRulesMitigatingcontrols, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRulesMitigatingcontrolsWrapper.prototype.Get = function (UID_NonCompliance, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_mitigatingcontrols_get(UID_NonCompliance, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRulesMitigatingcontrolsWrapper;
    }());
    var PortalRulesViolationsWrapper = /** @class */ (function () {
        function PortalRulesViolationsWrapper(client, translationProvider) {
            this.client = client;
            this.translationProvider = translationProvider;
        }
        /** Returns the runtime schema for this method. */
        PortalRulesViolationsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/rules/violations');
        };
        PortalRulesViolationsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/rules/violations');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRulesViolations, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRulesViolationsWrapper.prototype.Get = function (parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_violations_get(parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRulesViolationsWrapper;
    }());
    var PortalRulesWorkingcopiesMitigatingcontrolsWrapper = /** @class */ (function () {
        function PortalRulesWorkingcopiesMitigatingcontrolsWrapper(client, translationProvider) {
            var _this = this;
            this.client = client;
            this.translationProvider = translationProvider;
            this.commitMethod = function (entity, writeData) {
                {
                    return _this.client.portal_rules_workingcopies_mitigatingcontrols_post(entity.GetColumn('UID_ComplianceRule').GetValue(), writeData);
                }
            };
            this.deleteMethod = function (entity) {
                return _this.client.portal_rules_workingcopies_mitigatingcontrols_delete(entity.GetColumn('UID_ComplianceRule').GetValue(), entity.GetColumn('UID_MitigatingControl').GetValue());
            };
        }
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.createEntity = function (initialData) {
            this.buildBuilderIfNeeded();
            return this.builder.buildReadWriteEntity({ entitySchema: this.GetSchema(), entityData: initialData }, imxQbmDbts.EntityState.Created);
        };
        /** Returns the runtime schema for this method. */
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.GetSchema = function () {
            return this.client.getSchema('portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols');
        };
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.buildBuilderIfNeeded = function () {
            if (!this.builder) {
                var fkProviderItems = this.client.getFkProviderItems('portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols');
                this.builder = new imxQbmDbts.TypedEntityBuilder(PortalRulesWorkingcopiesMitigatingcontrols, fkProviderItems, this.commitMethod, this.translationProvider, this.deleteMethod);
            }
        };
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.Get = function (UID_ComplianceRule, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.Post = function (UID_ComplianceRule, inputParameterName, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule, inputParameterName.EntityWriteData, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        PortalRulesWorkingcopiesMitigatingcontrolsWrapper.prototype.Delete = function (UID_ComplianceRule, UID_MitigatingControl, parametersOptional, requestOpts) {
            if (parametersOptional === void 0) { parametersOptional = {}; }
            if (requestOpts === void 0) { requestOpts = {}; }
            return __awaiter(this, void 0, void 0, function () {
                var data;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0: return [4 /*yield*/, this.client.portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule, UID_MitigatingControl, parametersOptional, requestOpts)];
                        case 1:
                            data = _a.sent();
                            this.buildBuilderIfNeeded();
                            return [2 /*return*/, this.builder.buildReadWriteEntities(data, this.GetSchema())];
                    }
                });
            });
        };
        return PortalRulesWorkingcopiesMitigatingcontrolsWrapper;
    }());
    /** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
    var ApiClientMethodFactory = /** @class */ (function () {
        function ApiClientMethodFactory() {
        }
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName) {
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_compliance_config_get = function () {
            return {
                path: '/portal/compliance/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_itshop_requests_compliance_get = function (uid_personwantsorg) {
            return {
                path: '/portal/itshop/requests/{uid_personwantsorg}/compliance',
                parameters: [
                    {
                        name: 'uid_personwantsorg',
                        value: uid_personwantsorg,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_get = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_post = function (UID_Person, UID_NonCompliance, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_delete = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/{UID_PersonInNCHasMControl}',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_PersonInNCHasMControl',
                        value: UID_PersonInNCHasMControl,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_get = function (UID_Person, UID_NonCompliance) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_put = function (UID_Person, UID_NonCompliance, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_delete = function (UID_Person, UID_NonCompliance, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_forrequest_get = function (UID_Person, UID_NonCompliance, entityid, keys, state) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/{entityid}/forrequest',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'entityid',
                        value: entityid,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'keys',
                        value: keys,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_byid_get = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/{UID_PersonInNCHasMControl}',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_PersonInNCHasMControl',
                        value: UID_PersonInNCHasMControl,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post = function (UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post = function (UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName) {
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates/filtertree',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'parentkey',
                        value: parentkey,
                        in: 'query'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_person_rolememberships_NonCompliance_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/person/{UID_Person}/rolememberships/NonCompliance',
                parameters: [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_roles_config_compliance_get = function (roleTable, rolePk) {
            return {
                path: '/portal/roles/config/{roleTable}/{rolePk}/compliance',
                parameters: [
                    {
                        name: 'roleTable',
                        value: roleTable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'rolePk',
                        value: rolePk,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, active) {
            return {
                path: '/portal/rules',
                parameters: [
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'active',
                        value: active,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_mitigatingcontrols_get = function (UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/rules/{UID_NonCompliance}/mitigatingcontrols',
                parameters: [
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_recalculate_post = function (uid) {
            return {
                path: '/portal/rules/{uid}/recalculate',
                parameters: [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_report_get = function (uidrule) {
            return {
                path: '/portal/rules/{uidrule}/report',
                parameters: [
                    {
                        name: 'uidrule',
                        value: uidrule,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_datamodel_get = function (filter) {
            return {
                path: '/portal/rules/datamodel',
                parameters: [
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_group_get = function (by, def, filter, StartIndex, PageSize, withcount, active) {
            return {
                path: '/portal/rules/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'active',
                        value: active,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_get = function (approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_compliancerule) {
            return {
                path: '/portal/rules/violations',
                parameters: [
                    {
                        name: 'approvable',
                        value: approvable,
                        in: 'query'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'uid_compliancerule',
                        value: uid_compliancerule,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_post = function (uidperson, uidnoncompliance, inputParameterName) {
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_actions_post = function (uidperson, uidnoncompliance, inputParameterName) {
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/actions',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_analyzeloss_post = function (uidperson, uidnoncompliance, inputParameterName) {
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/analyzeloss',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_entitlements_get = function (uidperson, uidnoncompliance) {
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/entitlements',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_result_post = function (uidperson, uidnoncompliance, inputParameterName) {
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/result',
                parameters: [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_datamodel_get = function (approvable, filter) {
            return {
                path: '/portal/rules/violations/datamodel',
                parameters: [
                    {
                        name: 'approvable',
                        value: approvable,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_violations_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_compliancerule, approvable) {
            return {
                path: '/portal/rules/violations/group',
                parameters: [
                    {
                        name: 'by',
                        value: by,
                        in: 'query'
                    },
                    {
                        name: 'def',
                        value: def,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'withcount',
                        value: withcount,
                        in: 'query'
                    },
                    {
                        name: 'state',
                        value: state,
                        in: 'query'
                    },
                    {
                        name: 'uid_compliancerule',
                        value: uid_compliancerule,
                        in: 'query'
                    },
                    {
                        name: 'approvable',
                        value: approvable,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_get = function (UID_ComplianceRule, OrderBy, StartIndex, PageSize, filter, withProperties, search) {
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols',
                parameters: [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'OrderBy',
                        value: OrderBy,
                        in: 'query'
                    },
                    {
                        name: 'StartIndex',
                        value: StartIndex,
                        in: 'query'
                    },
                    {
                        name: 'PageSize',
                        value: PageSize,
                        in: 'query'
                    },
                    {
                        name: 'filter',
                        value: filter,
                        in: 'query'
                    },
                    {
                        name: 'withProperties',
                        value: withProperties,
                        in: 'query'
                    },
                    {
                        name: 'search',
                        value: search,
                        in: 'query'
                    },
                ],
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_post = function (UID_ComplianceRule, inputParameterName) {
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols',
                parameters: [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ],
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_delete = function (UID_ComplianceRule, UID_MitigatingControl) {
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols/{UID_MitigatingControl}',
                parameters: [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ],
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return ApiClientMethodFactory;
    }());
    /** @deprecated Use the V2Client class for a stable method interface. */
    var Client = /** @class */ (function () {
        function Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        Client.prototype.portal_candidates_MitigatingControl_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_compliance_config_get = function (requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_compliance_config_get(), requestOptions);
        };
        /** Returns the compliance check result for the specified request. */
        Client.prototype.portal_itshop_requests_compliance_get = function (uid_personwantsorg, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_itshop_requests_compliance_get(uid_personwantsorg), requestOptions);
        };
        Client.prototype.portal_person_mitigatingcontrols_get = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_get(UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Assign a mitigating control to the rule violation. */
        Client.prototype.portal_person_mitigatingcontrols_post = function (UID_Person, UID_NonCompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_post(UID_Person, UID_NonCompliance, inputParameterName), requestOptions);
        };
        /** Removes a mitigating control from the rule violation. */
        Client.prototype.portal_person_mitigatingcontrols_delete = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_delete(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl), requestOptions);
        };
        /** Assign a mitigating control to the rule violation. */
        Client.prototype.portal_person_mitigatingcontrols_interactive_get = function (UID_Person, UID_NonCompliance, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_get(UID_Person, UID_NonCompliance), requestOptions);
        };
        Client.prototype.portal_person_mitigatingcontrols_interactive_put = function (UID_Person, UID_NonCompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_put(UID_Person, UID_NonCompliance, inputParameterName), requestOptions);
        };
        /** Removes a mitigating control from the rule violation. */
        Client.prototype.portal_person_mitigatingcontrols_interactive_delete = function (UID_Person, UID_NonCompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_delete(UID_Person, UID_NonCompliance, inputParameterName), requestOptions);
        };
        /** Saves the mitigating control assignment for a specific request as a deferred operation. */
        Client.prototype.portal_person_mitigatingcontrols_interactive_forrequest_get = function (UID_Person, UID_NonCompliance, entityid, keys, state, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_forrequest_get(UID_Person, UID_NonCompliance, entityid, keys, state), requestOptions);
        };
        Client.prototype.portal_person_mitigatingcontrols_interactive_byid_get = function (UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_byid_get(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        Client.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates endpoint. */
        Client.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post = function (UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        Client.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post = function (UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(UID_Person, UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, inputParameterName), requestOptions);
        };
        /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates endpoint. */
        Client.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post = function (UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(UID_Person, UID_NonCompliance, filter, parentkey, inputParameterName), requestOptions);
        };
        Client.prototype.portal_person_rolememberships_NonCompliance_get = function (UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_NonCompliance_get(UID_Person, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        Client.prototype.portal_roles_config_compliance_get = function (roleTable, rolePk, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_compliance_get(roleTable, rolePk), requestOptions);
        };
        Client.prototype.portal_rules_get = function (OrderBy, StartIndex, PageSize, filter, withProperties, search, active, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_get(OrderBy, StartIndex, PageSize, filter, withProperties, search, active), requestOptions);
        };
        Client.prototype.portal_rules_mitigatingcontrols_get = function (UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_mitigatingcontrols_get(UID_NonCompliance, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Triggers a recalculation of the rule violations. */
        Client.prototype.portal_rules_recalculate_post = function (uid, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_recalculate_post(uid), requestOptions);
        };
        Client.prototype.portal_rules_report_get = function (uidrule, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_report_get(uidrule), requestOptions);
        };
        /** Returns data model information about query options for the rules endpoint. */
        Client.prototype.portal_rules_datamodel_get = function (filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_datamodel_get(filter), requestOptions);
        };
        Client.prototype.portal_rules_group_get = function (by, def, filter, StartIndex, PageSize, withcount, active, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_group_get(by, def, filter, StartIndex, PageSize, withcount, active), requestOptions);
        };
        Client.prototype.portal_rules_violations_get = function (approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_compliancerule, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_get(approvable, OrderBy, StartIndex, PageSize, filter, withProperties, search, state, uid_compliancerule), requestOptions);
        };
        Client.prototype.portal_rules_violations_post = function (uidperson, uidnoncompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_post(uidperson, uidnoncompliance, inputParameterName), requestOptions);
        };
        Client.prototype.portal_rules_violations_actions_post = function (uidperson, uidnoncompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_actions_post(uidperson, uidnoncompliance, inputParameterName), requestOptions);
        };
        Client.prototype.portal_rules_violations_analyzeloss_post = function (uidperson, uidnoncompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_analyzeloss_post(uidperson, uidnoncompliance, inputParameterName), requestOptions);
        };
        Client.prototype.portal_rules_violations_entitlements_get = function (uidperson, uidnoncompliance, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_entitlements_get(uidperson, uidnoncompliance), requestOptions);
        };
        Client.prototype.portal_rules_violations_result_post = function (uidperson, uidnoncompliance, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_result_post(uidperson, uidnoncompliance, inputParameterName), requestOptions);
        };
        /** Returns data model information about query options for the rules/violations endpoint. */
        Client.prototype.portal_rules_violations_datamodel_get = function (approvable, filter, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_datamodel_get(approvable, filter), requestOptions);
        };
        Client.prototype.portal_rules_violations_group_get = function (by, def, filter, StartIndex, PageSize, withcount, state, uid_compliancerule, approvable, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_group_get(by, def, filter, StartIndex, PageSize, withcount, state, uid_compliancerule, approvable), requestOptions);
        };
        Client.prototype.portal_rules_workingcopies_mitigatingcontrols_get = function (UID_ComplianceRule, OrderBy, StartIndex, PageSize, filter, withProperties, search, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule, OrderBy, StartIndex, PageSize, filter, withProperties, search), requestOptions);
        };
        /** Assign a mitigating control to the compliance rule. */
        Client.prototype.portal_rules_workingcopies_mitigatingcontrols_post = function (UID_ComplianceRule, inputParameterName, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule, inputParameterName), requestOptions);
        };
        /** Removes a mitigating control from the compliance rule. */
        Client.prototype.portal_rules_workingcopies_mitigatingcontrols_delete = function (UID_ComplianceRule, UID_MitigatingControl, requestOptions) {
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule, UID_MitigatingControl), requestOptions);
        };
        return Client;
    }());
    var V2ApiClientMethodFactory = /** @class */ (function () {
        function V2ApiClientMethodFactory() {
        }
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/candidates/MitigatingControl/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_compliance_config_get = function (options, requestOptions) {
            return {
                path: '/portal/compliance/config',
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_itshop_requests_compliance_get = function (/** Unique request identifier */ uid_personwantsorg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/itshop/requests/{uid_personwantsorg}/compliance',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid_personwantsorg',
                        value: uid_personwantsorg,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_delete = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, /** Mitigating control assignment */ UID_PersonInNCHasMControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/{UID_PersonInNCHasMControl}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_PersonInNCHasMControl',
                        value: UID_PersonInNCHasMControl,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_put = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'PUT',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_delete = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_forrequest_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, entityid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/{entityid}/forrequest',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'entityid',
                        value: entityid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_byid_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, /** Primary key value UID_PersonInNCHasMControl */ UID_PersonInNCHasMControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/{UID_PersonInNCHasMControl}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_PersonInNCHasMControl',
                        value: UID_PersonInNCHasMControl,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates/filtertree',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_person_rolememberships_NonCompliance_get = function (/** Unique identity identifier */ UID_Person, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/person/{UID_Person}/rolememberships/NonCompliance',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_Person',
                        value: UID_Person,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_roles_config_compliance_get = function (/** Type of the role */ roleTable, /** Unique identifier of the role */ rolePk, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/roles/config/{roleTable}/{rolePk}/compliance',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'roleTable',
                        value: roleTable,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'rolePk',
                        value: rolePk,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_mitigatingcontrols_get = function (/** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/{UID_NonCompliance}/mitigatingcontrols',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_NonCompliance',
                        value: UID_NonCompliance,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_recalculate_post = function (/** Unique rule identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/{uid}/recalculate',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uid',
                        value: uid,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_report_get = function (/** Unique rule identifier */ uidrule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/{uidrule}/report',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidrule',
                        value: uidrule,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_post = function (/** Unique identity identifier */ uidperson, /** Unique non-compliance identifier */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_actions_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/actions',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_analyzeloss_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/analyzeloss',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_entitlements_get = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/entitlements',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_result_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/{uidperson}/{uidnoncompliance}/result',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'uidperson',
                        value: uidperson,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'uidnoncompliance',
                        value: uidnoncompliance,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/datamodel',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_violations_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/violations/group',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, []),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_get = function (UID_ComplianceRule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'GET',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_post = function (UID_ComplianceRule, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'inputParameterName',
                        value: inputParameterName,
                        required: true,
                        in: 'body'
                    },
                ]),
                method: 'POST',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        V2ApiClientMethodFactory.prototype.portal_rules_workingcopies_mitigatingcontrols_delete = function (UID_ComplianceRule, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            return {
                path: '/portal/rules/workingcopies/{UID_ComplianceRule}/mitigatingcontrols/{UID_MitigatingControl}',
                parameters: imxQbmDbts.MethodDefinition.MakeQueryParameters(options, [
                    {
                        name: 'UID_ComplianceRule',
                        value: UID_ComplianceRule,
                        required: true,
                        in: 'path'
                    },
                    {
                        name: 'UID_MitigatingControl',
                        value: UID_MitigatingControl,
                        required: true,
                        in: 'path'
                    },
                ]),
                method: 'DELETE',
                headers: {
                    'imx-timezone': imxQbmDbts.TimeZoneInfo.get(),
                },
                credentials: 'include',
                observe: 'response',
                responseType: 'json'
            };
        };
        return V2ApiClientMethodFactory;
    }());
    var V2Client = /** @class */ (function () {
        function V2Client(apiClient, schemaProvider) {
            this.apiClient = apiClient;
            this.schemaProvider = schemaProvider;
            this.methodFactory = new V2ApiClientMethodFactory();
            if (!apiClient) {
                throw new Error("The value for the apiClient parameter is undefined.");
            }
        }
        Object.defineProperty(V2Client.prototype, "schemas", {
            get: function () {
                if (!this.schemaProvider) {
                    throw new Error("The schema has not been loaded.");
                }
                return this.schemaProvider.schemas;
            },
            enumerable: false,
            configurable: true
        });
        V2Client.prototype.loadSchema = function (language) {
            return __awaiter(this, void 0, void 0, function () {
                var headers, dtos, schemas, key, dto, columns;
                return __generator(this, function (_a) {
                    switch (_a.label) {
                        case 0:
                            headers = {};
                            if (language)
                                headers['Accept-Language'] = language;
                            return [4 /*yield*/, this.apiClient.processRequest({
                                    path: '/imx/entityschema',
                                    parameters: [],
                                    method: 'GET',
                                    headers: headers,
                                    credentials: 'include',
                                    observe: 'response',
                                    responseType: 'json'
                                })];
                        case 1:
                            dtos = _a.sent();
                            schemas = {};
                            for (key in dtos) {
                                dto = dtos[key];
                                columns = dto.Properties;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY;
                                columns[imxQbmDbts.DisplayColumns.DISPLAY_LONG_PROPERTYNAME] = imxQbmDbts.DisplayColumns.DISPLAY_PROPERTY_LONG;
                                schemas[key] = {
                                    TypeName: dto.TypeName,
                                    DisplayPattern: new imxQbmDbts.DisplayPattern(dto.DisplayPattern),
                                    Display: dto.Display,
                                    DisplaySingular: dto.DisplaySingular,
                                    FkCandidateRoutes: dto.FkCandidateRoutes,
                                    Columns: columns
                                };
                            }
                            this.schemaProvider = { schemas: schemas };
                            return [2 /*return*/];
                    }
                });
            });
        };
        V2Client.prototype.getFkProviderItems = function (methodKey) {
            var _a;
            return new imxQbmDbts.FkCandidateBuilder((_a = this.getSchema(methodKey)) === null || _a === void 0 ? void 0 : _a.FkCandidateRoutes, this.apiClient).build();
        };
        /** Returns the runtime schema for the named method. */
        V2Client.prototype.getSchema = function (methodKey) {
            var result = this.schemas[methodKey];
            if (!result)
                throw new Error('Unknown method: ' + methodKey);
            return result;
        };
        /** Returns a list of candidate objects from the table MitigatingControl. */
        V2Client.prototype.portal_candidates_MitigatingControl_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_get(options), requestOptions);
        };
        /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
        V2Client.prototype.portal_candidates_MitigatingControl_filtertree_post = function (inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_candidates_MitigatingControl_filtertree_post(inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_compliance_config_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_compliance_config_get(options), requestOptions);
        };
        /** Returns the compliance check result for the specified request. */
        V2Client.prototype.portal_itshop_requests_compliance_get = function (/** Unique request identifier */ uid_personwantsorg, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_itshop_requests_compliance_get(uid_personwantsorg, options), requestOptions);
        };
        V2Client.prototype.portal_person_mitigatingcontrols_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_get(UID_Person, UID_NonCompliance, options), requestOptions);
        };
        /** Assign a mitigating control to the rule violation. */
        V2Client.prototype.portal_person_mitigatingcontrols_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_post(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Removes a mitigating control from the rule violation. */
        V2Client.prototype.portal_person_mitigatingcontrols_delete = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, /** Mitigating control assignment */ UID_PersonInNCHasMControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_delete(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, options), requestOptions);
        };
        /** Assign a mitigating control to the rule violation. */
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_get(UID_Person, UID_NonCompliance, options), requestOptions);
        };
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_put = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_put(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Removes a mitigating control from the rule violation. */
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_delete = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_delete(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Saves the mitigating control assignment for a specific request as a deferred operation. */
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_forrequest_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, entityid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_forrequest_get(UID_Person, UID_NonCompliance, entityid, options), requestOptions);
        };
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_byid_get = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, /** Primary key value UID_PersonInNCHasMControl */ UID_PersonInNCHasMControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_byid_get(UID_Person, UID_NonCompliance, UID_PersonInNCHasMControl, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_post(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/interactive/UID_MitigatingControl/candidates endpoint. */
        V2Client.prototype.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_interactive_UID_MitigatingControl_candidates_filtertree_post(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
        V2Client.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_post(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        /** Returns filter tree information for the person/{UID_Person}/mitigatingcontrols/{UID_NonCompliance}/UID_MitigatingControl/candidates endpoint. */
        V2Client.prototype.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post = function (/** Unique identity identifier */ UID_Person, /** Unique rule violation identifier */ UID_NonCompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_mitigatingcontrols_UID_MitigatingControl_candidates_filtertree_post(UID_Person, UID_NonCompliance, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_person_rolememberships_NonCompliance_get = function (/** Unique identity identifier */ UID_Person, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_person_rolememberships_NonCompliance_get(UID_Person, options), requestOptions);
        };
        V2Client.prototype.portal_roles_config_compliance_get = function (/** Type of the role */ roleTable, /** Unique identifier of the role */ rolePk, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_roles_config_compliance_get(roleTable, rolePk, options), requestOptions);
        };
        V2Client.prototype.portal_rules_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_mitigatingcontrols_get = function (/** Unique rule violation identifier */ UID_NonCompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_mitigatingcontrols_get(UID_NonCompliance, options), requestOptions);
        };
        /** Triggers a recalculation of the rule violations. */
        V2Client.prototype.portal_rules_recalculate_post = function (/** Unique rule identifier */ uid, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_recalculate_post(uid, options), requestOptions);
        };
        V2Client.prototype.portal_rules_report_get = function (/** Unique rule identifier */ uidrule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_report_get(uidrule, options), requestOptions);
        };
        /** Returns data model information about query options for the rules endpoint. */
        V2Client.prototype.portal_rules_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_group_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_post = function (/** Unique identity identifier */ uidperson, /** Unique non-compliance identifier */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_post(uidperson, uidnoncompliance, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_actions_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_actions_post(uidperson, uidnoncompliance, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_analyzeloss_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_analyzeloss_post(uidperson, uidnoncompliance, inputParameterName, options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_entitlements_get = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_entitlements_get(uidperson, uidnoncompliance, options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_result_post = function (/** Identifier of the identity with the rule violation */ uidperson, /** Identifier of the compliance violation node */ uidnoncompliance, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_result_post(uidperson, uidnoncompliance, inputParameterName, options), requestOptions);
        };
        /** Returns data model information about query options for the rules/violations endpoint. */
        V2Client.prototype.portal_rules_violations_datamodel_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_datamodel_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_violations_group_get = function (options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_violations_group_get(options), requestOptions);
        };
        V2Client.prototype.portal_rules_workingcopies_mitigatingcontrols_get = function (UID_ComplianceRule, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_get(UID_ComplianceRule, options), requestOptions);
        };
        /** Assign a mitigating control to the compliance rule. */
        V2Client.prototype.portal_rules_workingcopies_mitigatingcontrols_post = function (UID_ComplianceRule, inputParameterName, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_post(UID_ComplianceRule, inputParameterName, options), requestOptions);
        };
        /** Removes a mitigating control from the compliance rule. */
        V2Client.prototype.portal_rules_workingcopies_mitigatingcontrols_delete = function (UID_ComplianceRule, /** Mitigating control */ UID_MitigatingControl, options, requestOptions) {
            if (options === void 0) { options = {}; }
            if (requestOptions === void 0) { requestOptions = {}; }
            return this.apiClient.processRequest(this.methodFactory.portal_rules_workingcopies_mitigatingcontrols_delete(UID_ComplianceRule, UID_MitigatingControl, options), requestOptions);
        };
        return V2Client;
    }());

    exports.ApiClientMethodFactory = ApiClientMethodFactory;
    exports.Client = Client;
    exports.PortalCandidatesMitigatingcontrol = PortalCandidatesMitigatingcontrol;
    exports.PortalCandidatesMitigatingcontrolInteractive = PortalCandidatesMitigatingcontrolInteractive;
    exports.PortalCandidatesMitigatingcontrolWrapper = PortalCandidatesMitigatingcontrolWrapper;
    exports.PortalPersonMitigatingcontrols = PortalPersonMitigatingcontrols;
    exports.PortalPersonMitigatingcontrolsInteractive = PortalPersonMitigatingcontrolsInteractive;
    exports.PortalPersonMitigatingcontrolsInteractiveWrapper = PortalPersonMitigatingcontrolsInteractiveWrapper;
    exports.PortalPersonMitigatingcontrolsWrapper = PortalPersonMitigatingcontrolsWrapper;
    exports.PortalPersonRolemembershipsNoncompliance = PortalPersonRolemembershipsNoncompliance;
    exports.PortalPersonRolemembershipsNoncomplianceInteractive = PortalPersonRolemembershipsNoncomplianceInteractive;
    exports.PortalPersonRolemembershipsNoncomplianceWrapper = PortalPersonRolemembershipsNoncomplianceWrapper;
    exports.PortalRules = PortalRules;
    exports.PortalRulesInteractive = PortalRulesInteractive;
    exports.PortalRulesMitigatingcontrols = PortalRulesMitigatingcontrols;
    exports.PortalRulesMitigatingcontrolsInteractive = PortalRulesMitigatingcontrolsInteractive;
    exports.PortalRulesMitigatingcontrolsWrapper = PortalRulesMitigatingcontrolsWrapper;
    exports.PortalRulesViolations = PortalRulesViolations;
    exports.PortalRulesViolationsInteractive = PortalRulesViolationsInteractive;
    exports.PortalRulesViolationsWrapper = PortalRulesViolationsWrapper;
    exports.PortalRulesWorkingcopiesMitigatingcontrols = PortalRulesWorkingcopiesMitigatingcontrols;
    exports.PortalRulesWorkingcopiesMitigatingcontrolsInteractive = PortalRulesWorkingcopiesMitigatingcontrolsInteractive;
    exports.PortalRulesWorkingcopiesMitigatingcontrolsWrapper = PortalRulesWorkingcopiesMitigatingcontrolsWrapper;
    exports.PortalRulesWrapper = PortalRulesWrapper;
    exports.TypedClient = TypedClient;
    exports.V2ApiClientMethodFactory = V2ApiClientMethodFactory;
    exports.V2Client = V2Client;

    Object.defineProperty(exports, '__esModule', { value: true });

})));
