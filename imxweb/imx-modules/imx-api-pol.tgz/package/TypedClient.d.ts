import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntityData, EntityKeysData, EntitySchema, EntityWriteData, EntityWriteDataSingle, ExtendedEntityCollectionData, FilterData, FilterTreeData, FkProviderItem, GroupInfoData, IReadValue, IWriteValue, MethodDescriptor, ReadExtTypedEntity, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export interface ExtendedEntityCollectionDataOfPolicyViolationExtendedData extends EntityCollectionData {
    ExtendedData?: PolicyViolationExtendedData;
}
export interface ObjectInfo {
    Display?: string;
    ObjectKey?: string;
}
export interface PolicyConfig {
    IsPolicyEnabled: boolean;
    MitigatingControlsPerViolation: boolean;
}
export interface PolicyViolationDecisionInput {
    ExceptionValidUntil?: Date;
    Reason?: string;
    UidJustification?: string;
    Decision: boolean;
}
export interface PolicyViolationExtendedData {
    RelatedObjects?: ObjectInfo[][];
}
export declare class TypedClient {
    readonly PortalCandidatesMitigatingcontrol: PortalCandidatesMitigatingcontrolWrapper;
    readonly PortalPolicies: PortalPoliciesWrapper;
    readonly PortalPoliciesMitigatingcontrols: PortalPoliciesMitigatingcontrolsWrapper;
    readonly PortalPoliciesViolations: PortalPoliciesViolationsWrapper;
    readonly PortalPoliciesViolationslist: PortalPoliciesViolationslistWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalCandidatesMitigatingcontrol extends TypedEntity {
    readonly XObjectKey: IReadValue<string>;
    readonly UID_MitigatingControl: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XObjectKey' | 'UID_MitigatingControl'>;
}
/** @deprecated Use the PortalCandidatesMitigatingcontrol type. */
export declare class PortalCandidatesMitigatingcontrolInteractive extends PortalCandidatesMitigatingcontrol {
}
export declare class PortalPolicies extends TypedEntity {
    readonly Description: IReadValue<string>;
    readonly Ident_QERPolicy: IReadValue<string>;
    readonly IsExceptionAllowed: IReadValue<boolean>;
    readonly IsInActive: IReadValue<boolean>;
    readonly IsWorkingCopy: IReadValue<boolean>;
    readonly RiskIndex: IReadValue<number>;
    readonly RiskIndexReduced: IReadValue<number>;
    readonly RuleSeverity: IReadValue<number>;
    readonly RuleViolationThreshold: IReadValue<number>;
    readonly SignificancyClass: IReadValue<number>;
    readonly StateInfo: IReadValue<string>;
    readonly TransparencyIndex: IReadValue<number>;
    readonly UID_AERoleAttestator: IReadValue<string>;
    readonly UID_AERoleResponsible: IReadValue<string>;
    readonly UID_AERoleRuler: IReadValue<string>;
    readonly UID_DialogReport: IReadValue<string>;
    readonly UID_DialogTable: IReadValue<string>;
    readonly UID_QERPolicy: IReadValue<string>;
    readonly UID_QERPolicyWork: IReadValue<string>;
    readonly UID_QERPolicyGroup: IReadValue<string>;
    readonly CountOpen: IReadValue<number>;
    readonly CountClosed: IReadValue<number>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'Description' | 'Ident_QERPolicy' | 'IsExceptionAllowed' | 'IsInActive' | 'IsWorkingCopy' | 'RiskIndex' | 'RiskIndexReduced' | 'RuleSeverity' | 'RuleViolationThreshold' | 'SignificancyClass' | 'StateInfo' | 'TransparencyIndex' | 'UID_AERoleAttestator' | 'UID_AERoleResponsible' | 'UID_AERoleRuler' | 'UID_DialogReport' | 'UID_DialogTable' | 'UID_QERPolicy' | 'UID_QERPolicyWork' | 'UID_QERPolicyGroup' | 'CountOpen' | 'CountClosed'>;
}
/** @deprecated Use the PortalPolicies type. */
export declare class PortalPoliciesInteractive extends PortalPolicies {
}
export declare class PortalPoliciesMitigatingcontrols extends TypedEntity {
    readonly UID_QERPolicy: IReadValue<string>;
    readonly UID_MitigatingControl: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_QERPolicy' | 'UID_MitigatingControl'>;
}
/** @deprecated Use the PortalPoliciesMitigatingcontrols type. */
export declare class PortalPoliciesMitigatingcontrolsInteractive extends PortalPoliciesMitigatingcontrols {
}
export declare class PortalPoliciesViolations extends TypedEntity {
    readonly UID_QERPolicyHasObject: IReadValue<string>;
    readonly UID_MitigatingControl: IWriteValue<string>;
    readonly ObjectKey: IReadValue<string>;
    readonly UID_QERPolicy: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_QERPolicyHasObject' | 'UID_MitigatingControl' | 'ObjectKey' | 'UID_QERPolicy'>;
}
/** @deprecated Use the PortalPoliciesViolations type. */
export declare class PortalPoliciesViolationsInteractive extends PortalPoliciesViolations {
}
export declare class PortalPoliciesViolationslist extends ReadExtTypedEntity<PolicyViolationExtendedData> {
    readonly XDateInserted: IReadValue<Date>;
    readonly DecisionDate: IReadValue<Date>;
    readonly DecisionReason: IReadValue<string>;
    readonly UID_QERPolicy: IReadValue<string>;
    readonly ObjectKey: IReadValue<string>;
    readonly UID_PersonDecisionMade: IReadValue<string>;
    readonly UID_QERJustification: IReadValue<string>;
    readonly State: IReadValue<string>;
    readonly Description: IReadValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'XDateInserted' | 'DecisionDate' | 'DecisionReason' | 'UID_QERPolicy' | 'ObjectKey' | 'UID_PersonDecisionMade' | 'UID_QERJustification' | 'State' | 'Description'>;
}
/** @deprecated Use the PortalPoliciesViolationslist type. */
export declare class PortalPoliciesViolationslistInteractive extends PortalPoliciesViolationslist {
}
export declare class PortalCandidatesMitigatingcontrolWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_candidates_MitigatingControl_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalCandidatesMitigatingcontrol, unknown>>;
}
export declare class PortalPoliciesWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_policies_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPolicies, unknown>>;
}
export declare class PortalPoliciesMitigatingcontrolsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPoliciesMitigatingcontrols;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_QERPolicy: string, parametersOptional?: portal_policies_mitigatingcontrols_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesMitigatingcontrols, unknown>>;
    Post(UID_QERPolicy: string, inputParameterName: PortalPoliciesMitigatingcontrols, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesMitigatingcontrols, unknown>>;
    Delete(UID_QERPolicy: string, UID_MitigatingControl: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesMitigatingcontrols, unknown>>;
}
export declare class PortalPoliciesViolationsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    createEntity(initialData?: EntityData): PortalPoliciesViolations;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_QERPolicyHasObject: string, parametersOptional?: portal_policies_violations_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesViolations, unknown>>;
    Post(UID_QERPolicyHasObject: string, inputParameterName: PortalPoliciesViolations, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesViolations, unknown>>;
    Delete(UID_QERPolicyHasObject: string, UID_MitigatingControl: string, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesViolations, unknown>>;
}
export declare class PortalPoliciesViolationslistWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get_list(parametersOptional?: portal_policies_violations_list_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalPoliciesViolationslist, PolicyViolationExtendedData>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_policies_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_get(UID_QERPolicy: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_post(UID_QERPolicy: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_delete(UID_QERPolicy: string, UID_MitigatingControl: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_report_get(uidpolicy: string): MethodDescriptor<void>;
    portal_policies_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_policies_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string): MethodDescriptor<GroupInfoData>;
    portal_policies_violations_list_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_qerpolicy: string): MethodDescriptor<ExtendedEntityCollectionData<PolicyViolationExtendedData>>;
    portal_policies_violations_get(UID_QERPolicyHasObject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_delete(UID_QERPolicyHasObject: string, UID_MitigatingControl: string): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle): MethodDescriptor<FilterTreeData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput): MethodDescriptor<void>;
    portal_policies_violations_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
    portal_policies_violations_group_list_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_qerpolicy: string): MethodDescriptor<GroupInfoData>;
    portal_policy_config_get(): MethodDescriptor<PolicyConfig>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_policies_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, active: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_mitigatingcontrols_get(UID_QERPolicy: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the company policy. */
    portal_policies_mitigatingcontrols_post(UID_QERPolicy: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the company policy. */
    portal_policies_mitigatingcontrols_delete(UID_QERPolicy: string, UID_MitigatingControl: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_report_get(uidpolicy: string, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies endpoint. */
    portal_policies_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_policies_group_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, active: string, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    /** Returns a list of policy violations. */
    portal_policies_violations_list_get(approvable: boolean, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, state: string, uid_qerpolicy: string, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyViolationExtendedData>>;
    portal_policies_violations_get(UID_QERPolicyHasObject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the policy violation. */
    portal_policies_violations_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the policy violation. */
    portal_policies_violations_delete(UID_QERPolicyHasObject: string, UID_MitigatingControl: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, inputParameterName: EntityKeysData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates endpoint. */
    portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject: string, filter: FilterData[], parentkey: string, inputParameterName: EntityWriteDataSingle, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_policies_violations_approve_post(uidviolation: string, inputParameterName: PolicyViolationDecisionInput, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies/violations endpoint. */
    portal_policies_violations_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of policy violations. */
    portal_policies_violations_group_list_get(by: string, def: string, filter: FilterData[], StartIndex: number, PageSize: number, withcount: boolean, state: string, uid_qerpolicy: string, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_policy_config_get(requestOptions?: ApiRequestOptions): Promise<PolicyConfig>;
}
export interface portal_candidates_MitigatingControl_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_candidates_MitigatingControl_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_policies_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by status */ active?: string;
}
export interface portal_policies_mitigatingcontrols_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_policies_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_policies_group_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
    /** Filter by status */ active?: string;
}
export interface portal_policies_violations_list_get_args {
    /** Filters only policy violations approvable by the current user. */ approvable?: boolean;
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by status */ state?: string;
    /** Filters by a specific company policy */ uid_qerpolicy?: string;
}
export interface portal_policies_violations_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_policies_violations_UID_MitigatingControl_candidates_post_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post_args {
    /** Filter definition */ filter?: FilterData[];
    /** Parent key */ parentkey?: string;
}
export interface portal_policies_violations_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export interface portal_policies_violations_group_list_get_args {
    /** Comma-seperated list of columns */ by?: string;
    /** Pipe-seperated list of grouping definition data */ def?: string;
    /** Filter definition */ filter?: FilterData[];
    /** Index of first group to return */ StartIndex?: number;
    /** Number of groups to return */ PageSize?: number;
    /** Includes count of items for each group */ withcount?: boolean;
    /** Filter by status */ state?: string;
    /** Filters by a specific company policy */ uid_qerpolicy?: string;
}
export declare class V2ApiClientMethodFactory {
    portal_candidates_MitigatingControl_get(options?: portal_candidates_MitigatingControl_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_MitigatingControl_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_policies_get(options?: portal_policies_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_get(UID_QERPolicy: string, options?: portal_policies_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_post(UID_QERPolicy: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_mitigatingcontrols_delete(UID_QERPolicy: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_report_get(/** Unique policy identifier */ uidpolicy: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_policies_datamodel_get(options?: portal_policies_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_policies_group_get(options?: portal_policies_group_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_policies_violations_list_get(options?: portal_policies_violations_list_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<ExtendedEntityCollectionData<PolicyViolationExtendedData>>;
    portal_policies_violations_get(UID_QERPolicyHasObject: string, options?: portal_policies_violations_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_delete(UID_QERPolicyHasObject: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject: string, inputParameterName: EntityKeysData, options?: portal_policies_violations_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteDataSingle, options?: portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): MethodDescriptor<FilterTreeData>;
    portal_policies_violations_approve_post(/** Unique violation identifier */ uidviolation: string, inputParameterName: PolicyViolationDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_policies_violations_datamodel_get(options?: portal_policies_violations_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
    portal_policies_violations_group_list_get(options?: portal_policies_violations_group_list_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<GroupInfoData>;
    portal_policy_config_get(options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<PolicyConfig>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    /** Returns a list of candidate objects from the table MitigatingControl. */
    portal_candidates_MitigatingControl_get(options?: portal_candidates_MitigatingControl_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the candidates/MitigatingControl endpoint. */
    portal_candidates_MitigatingControl_filtertree_post(inputParameterName: EntityWriteDataSingle, options?: portal_candidates_MitigatingControl_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_policies_get(options?: portal_policies_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_mitigatingcontrols_get(UID_QERPolicy: string, options?: portal_policies_mitigatingcontrols_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the company policy. */
    portal_policies_mitigatingcontrols_post(UID_QERPolicy: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the company policy. */
    portal_policies_mitigatingcontrols_delete(UID_QERPolicy: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_policies_report_get(/** Unique policy identifier */ uidpolicy: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies endpoint. */
    portal_policies_datamodel_get(options?: portal_policies_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    portal_policies_group_get(options?: portal_policies_group_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    /** Returns a list of policy violations. */
    portal_policies_violations_list_get(options?: portal_policies_violations_list_get_args, requestOptions?: ApiRequestOptions): Promise<ExtendedEntityCollectionData<PolicyViolationExtendedData>>;
    portal_policies_violations_get(UID_QERPolicyHasObject: string, options?: portal_policies_violations_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Assign a mitigating control to the policy violation. */
    portal_policies_violations_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Removes a mitigating control from the policy violation. */
    portal_policies_violations_delete(UID_QERPolicyHasObject: string, /** Mitigating control */ UID_MitigatingControl: string, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns a list of objects that can be assigned to the property UID_MitigatingControl. */
    portal_policies_violations_UID_MitigatingControl_candidates_post(UID_QERPolicyHasObject: string, inputParameterName: EntityKeysData, options?: portal_policies_violations_UID_MitigatingControl_candidates_post_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    /** Returns filter tree information for the policies/violations/{UID_QERPolicyHasObject}/UID_MitigatingControl/candidates endpoint. */
    portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post(UID_QERPolicyHasObject: string, inputParameterName: EntityWriteDataSingle, options?: portal_policies_violations_UID_MitigatingControl_candidates_filtertree_post_args, requestOptions?: ApiRequestOptions): Promise<FilterTreeData>;
    portal_policies_violations_approve_post(/** Unique violation identifier */ uidviolation: string, inputParameterName: PolicyViolationDecisionInput, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the policies/violations endpoint. */
    portal_policies_violations_datamodel_get(options?: portal_policies_violations_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
    /** Returns a list of policy violations. */
    portal_policies_violations_group_list_get(options?: portal_policies_violations_group_list_get_args, requestOptions?: ApiRequestOptions): Promise<GroupInfoData>;
    portal_policy_config_get(options?: {}, requestOptions?: ApiRequestOptions): Promise<PolicyConfig>;
}
