import { ApiClient, ApiRequestOptions, DataModel, EntityCollectionData, EntitySchema, EntityWriteData, EntityWriteDataColumn, FilterData, FkProviderItem, IReadValue, IWriteValue, MethodDescriptor, StaticSchema, TypedEntity } from 'imx-qbm-dbts';
export interface EntityWriteDataBulk {
    Keys?: string[][];
    Data?: EntityWriteDataColumn[];
}
/** DTO for exception data. */
export interface ExceptionData {
    /** Gets or sets the exception message. */
    Message?: string;
    /** Gets or sets the error number for ViException-typed exceptions. */
    Number: number;
}
export declare class TypedClient {
    readonly PortalTargetsystemTeams: PortalTargetsystemTeamsWrapper;
    readonly PortalTargetsystemTeamsChannels: PortalTargetsystemTeamsChannelsWrapper;
    constructor(client: V2Client, translationProvider?: any);
}
export declare class PortalTargetsystemTeams extends TypedEntity {
    readonly WebUrl: IReadValue<string>;
    readonly UID_O3EUnifiedGroup: IReadValue<string>;
    readonly IsArchived: IWriteValue<boolean>;
    readonly fsAllowCustomMemes: IWriteValue<boolean>;
    readonly fsAllowGiphy: IWriteValue<boolean>;
    readonly fsAllowStickersAndMemes: IWriteValue<boolean>;
    readonly fsGiphyContentRating: IWriteValue<string>;
    readonly gsAllowCreateUpdateChannels: IWriteValue<boolean>;
    readonly gsAllowDeleteChannels: IWriteValue<boolean>;
    readonly msAllowChannelMentions: IWriteValue<boolean>;
    readonly msAllowOwnerDeleteMessages: IWriteValue<boolean>;
    readonly msAllowTeamMentions: IWriteValue<boolean>;
    readonly msAllowUserDeleteMessages: IWriteValue<boolean>;
    readonly msAllowUserEditMessages: IWriteValue<boolean>;
    readonly tmsAllowAddRemoveApps: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateChannels: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateRemoveConn: IWriteValue<boolean>;
    readonly tmsAllowCreateUpdateRemoveTabs: IWriteValue<boolean>;
    readonly tmsAllowDeleteChannels: IWriteValue<boolean>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'WebUrl' | 'UID_O3EUnifiedGroup' | 'IsArchived' | 'fsAllowCustomMemes' | 'fsAllowGiphy' | 'fsAllowStickersAndMemes' | 'fsGiphyContentRating' | 'gsAllowCreateUpdateChannels' | 'gsAllowDeleteChannels' | 'msAllowChannelMentions' | 'msAllowOwnerDeleteMessages' | 'msAllowTeamMentions' | 'msAllowUserDeleteMessages' | 'msAllowUserEditMessages' | 'tmsAllowAddRemoveApps' | 'tmsAllowCreateUpdateChannels' | 'tmsAllowCreateUpdateRemoveConn' | 'tmsAllowCreateUpdateRemoveTabs' | 'tmsAllowDeleteChannels'>;
}
/** @deprecated Use the PortalTargetsystemTeams type. */
export declare class PortalTargetsystemTeamsInteractive extends PortalTargetsystemTeams {
}
export declare class PortalTargetsystemTeamsChannels extends TypedEntity {
    readonly UID_O3TTeam: IReadValue<string>;
    readonly WebUrl: IReadValue<string>;
    readonly Id: IReadValue<string>;
    readonly EMail: IReadValue<string>;
    readonly Description: IWriteValue<string>;
    readonly DisplayName: IWriteValue<string>;
    /** Returns the static compile time schema for this type. */
    static GetEntitySchema(): StaticSchema<'UID_O3TTeam' | 'WebUrl' | 'Id' | 'EMail' | 'Description' | 'DisplayName'>;
}
/** @deprecated Use the PortalTargetsystemTeamsChannels type. */
export declare class PortalTargetsystemTeamsChannelsInteractive extends PortalTargetsystemTeamsChannels {
}
export declare class PortalTargetsystemTeamsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(parametersOptional?: portal_targetsystem_teams_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeams, unknown>>;
    Put(inputParameterName: PortalTargetsystemTeams, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeams, unknown>>;
}
export declare class PortalTargetsystemTeamsChannelsWrapper {
    private readonly client;
    private readonly translationProvider;
    private builder;
    constructor(client: V2Client, translationProvider: any);
    private commitMethod;
    private deleteMethod;
    /** Returns the runtime schema for this method. */
    GetSchema(): EntitySchema;
    private buildBuilderIfNeeded;
    Get(UID_O3TTeam: string, parametersOptional?: portal_targetsystem_teams_channels_get_args, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeamsChannels, unknown>>;
    Put(UID_O3TTeam: string, inputParameterName: PortalTargetsystemTeamsChannels, parametersOptional?: {}, requestOpts?: ApiRequestOptions): Promise<import("imx-qbm-dbts").ExtendedTypedEntityCollection<PortalTargetsystemTeamsChannels, unknown>>;
}
/** @deprecated Use the V2ApiClientMethodFactory class for a stable method interface. */
export declare class ApiClientMethodFactory {
    portal_targetsystem_teams_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, organization: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk): MethodDescriptor<void>;
    portal_targetsystem_teams_datamodel_get(filter: FilterData[]): MethodDescriptor<DataModel>;
}
/** @deprecated Use the V2Client class for a stable method interface. */
export declare class Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_targetsystem_teams_get(OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, organization: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(UID_O3TTeam: string, OrderBy: string, StartIndex: number, PageSize: number, filter: FilterData[], withProperties: string, search: string, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(UID_O3TTeam: string, inputParameterName: EntityWriteData, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    portal_targetsystem_teams_datamodel_get(filter: FilterData[], requestOptions?: ApiRequestOptions): Promise<DataModel>;
}
export interface portal_targetsystem_teams_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
    /** Filter by tenant */ organization?: string;
}
export interface portal_targetsystem_teams_channels_get_args {
    /** ORDER BY clause */ OrderBy?: string;
    /** Index of first entity to return */ StartIndex?: number;
    /** Number of entities to return */ PageSize?: number;
    /** Filter definition */ filter?: FilterData[];
    /** Comma-seperated list of properties to include in the result set. Prefix the list with the - character to exclude the default properties. */ withProperties?: string;
    /** Search term */ search?: string;
}
export interface portal_targetsystem_teams_datamodel_get_args {
    /** Filter definition */ filter?: FilterData[];
}
export declare class V2ApiClientMethodFactory {
    portal_targetsystem_teams_get(options?: portal_targetsystem_teams_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(/** Unique team identifier */ UID_O3TTeam: string, options?: portal_targetsystem_teams_channels_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(/** Unique team identifier */ UID_O3TTeam: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(/** Unique team identifier */ UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): MethodDescriptor<void>;
    portal_targetsystem_teams_datamodel_get(options?: portal_targetsystem_teams_datamodel_get_args, requestOptions?: ApiRequestOptions): MethodDescriptor<DataModel>;
}
export declare class V2Client {
    private readonly apiClient;
    private schemaProvider?;
    private readonly methodFactory;
    constructor(apiClient: ApiClient, schemaProvider?: {
        readonly schemas: {
            [key: string]: EntitySchema;
        };
    });
    get schemas(): {
        [key: string]: EntitySchema;
    };
    loadSchema(language?: string): Promise<void>;
    getFkProviderItems(methodKey: string): FkProviderItem[];
    /** Returns the runtime schema for the named method. */
    getSchema(methodKey: string): EntitySchema;
    portal_targetsystem_teams_get(options?: portal_targetsystem_teams_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_put(inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_get(/** Unique team identifier */ UID_O3TTeam: string, options?: portal_targetsystem_teams_channels_get_args, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_put(/** Unique team identifier */ UID_O3TTeam: string, inputParameterName: EntityWriteData, options?: {}, requestOptions?: ApiRequestOptions): Promise<EntityCollectionData>;
    portal_targetsystem_teams_channels_bulk_put(/** Unique team identifier */ UID_O3TTeam: string, inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    portal_targetsystem_teams_bulk_put(inputParameterName: EntityWriteDataBulk, options?: {}, requestOptions?: ApiRequestOptions): Promise<void>;
    /** Returns data model information about query options for the targetsystem/teams endpoint. */
    portal_targetsystem_teams_datamodel_get(options?: portal_targetsystem_teams_datamodel_get_args, requestOptions?: ApiRequestOptions): Promise<DataModel>;
}
